# 箱根駅伝可視化プロジェクト向けの Word Cloud のサンプル

```
python3 -m venv ~/.venvs/hakone_wc
source ~/.venvs/hakone_wc/bin/activate
pip install --upgrade hakone_wordcloud_snkw
```
